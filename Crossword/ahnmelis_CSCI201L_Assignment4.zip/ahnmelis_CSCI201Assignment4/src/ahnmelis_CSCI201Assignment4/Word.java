package ahnmelis_CSCI201Assignment4;

import java.util.ArrayList;

public class Word {
	private ArrayList<Letter> letters;
	private int length;
	private boolean used;
	private boolean ori; //true for across, false for down
	private int number;
	private int row;
	private int column;
	private String answer;
	private String string_form;
	
	public Word(int n, String w, boolean o, String a) {
		number = n;
		ori = o;
		length = w.length();
		used = false;
		row = -1;
		column = -1;
		letters = new ArrayList<Letter>();
		for (int i = 0; i < w.length(); i++) {
			letters.add(new Letter(w.charAt(i)));
		}
		string_form = w;
		answer = a;
		
	}
	
	public ArrayList<Letter> getLetters() {
		return letters;
	}
	
	public boolean getUsed() {
		return used;
	}
	
	public void setUsed(boolean used) {
		this.used = used;
	}

	public boolean getOri() {
		return ori;
	}
	
	public int getLength() {
		return length;
	}
	
	public int getNumber() {
		return number;
	}
	
	public int getRow() {
		return row;
	}
	
	public void setRow(int r) {
		row = r;
	}
	
	public int getColumn() {
		return column;
	}
	
	public void setColumn(int c) {
		column = c;
	}
	
	public String getAnswer() {
		return answer;
	}
	
	public String getStringForm() {
		return string_form;
	}

}
