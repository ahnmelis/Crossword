package ahnmelis_CSCI201Assignment4;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;
import java.util.Vector;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class GameServer {
	private Vector<ServerThread> serverThreads;
	private Vector<Lock> locks;
	private Vector<Condition> conditions;
	boolean first_player;
	Board crossword;
	static int num_players = 0;
	static int connected_players = -1;
	static String buffer = null; //trying to use this to send answers from Clients to GameServer through ServerThread
	static int question = 1;
	static boolean started = false;
	static boolean one_player = false;
	static boolean finished = false;
	static boolean wait = false;
	static boolean wait2 = true;
	
	static int[] points;
	
	public GameServer(int port) {
		ServerSocket ss = null;
		//flag for first player
		first_player = true;
		try {
			System.out.println("Trying to bind to port " + port);
			ss = new ServerSocket(port);
			System.out.println("Listening on port " + port);

			
			//instantiate FileParser
			FileParser fp = new FileParser("gamedata");
			//random number generator
			Random rand = new Random();
			//range of the random files indices
			int num_files; 
			
			while(true) {
				System.out.println("Waiting for players...");
				//top of the game
				started = false;
				num_players = 0;
				connected_players = -1;
				first_player = true;
				one_player = false;
				finished = false;
				wait = false;
				wait2 = true;
				//serverThread will be added for every new user
				serverThreads = new Vector<ServerThread>();
				//instantiate locks and conditions
				locks = new Vector<Lock>();
				conditions = new Vector<Condition>();
				
				boolean file_found = false;
				
				while (num_players != connected_players) {
					num_files = fp.files.size();
					Socket s = ss.accept(); //block
					System.out.println("Connection from " + s.getInetAddress()); //client was connected
					
					//create new lock and condition
					Lock temp =  new ReentrantLock();
					locks.add(temp);
					conditions.add(temp.newCondition());
					ServerThread st;
					if (first_player) {
						st = new ServerThread(s, this, locks.lastElement(), conditions.lastElement(), connected_players + 1);
					}
					else {
						st = new ServerThread(s, this, locks.lastElement(), conditions.lastElement(), connected_players);
					}
					serverThreads.add(st);
					//if it's the first player, need to ask for number of players
					if (first_player) {
						//need to ask player how many players there will be
						 //need to create some sort of blocking method just to find number of players
						queryNumPlayers(st);
						//once it obtains number of players
						System.out.println("Number of players: " + num_players);
						
						if (num_players == 1) {
							one_player = true;
						}
						first_player = false;
						connected_players = 1;
						
						//try to read random file
						System.out.println("Reading random game file.");
						int incorrect = 0;
						boolean read[] = new boolean[num_files];
						for (int i = 0; i < num_files; i++) {
							read[i] = false;
						}
						file_found = false;
						while (incorrect != num_files) {
							int index = rand.nextInt(num_files);
							if (fp.parse(index) == null && read[index] == false) {
								read[index] = true;
								incorrect++;	
							}
							else if (fp.parse(index) != null) {
								//save board
								crossword = fp.parse(index);
								crossword.render();
								file_found = true;
								break;
							}
						}
						
						if (file_found == false) {
							System.out.println("Could not find a file that was formatted correctly.");
							st.sendMessage("All files are not formatted correctly. Will look again when next client connects.");
						}
						else {
							System.out.println("File read successfully.");
						}
					}
					
					else {
						if (file_found == false) {
							//try to read random file
							System.out.println("Reading random game file.");
							int incorrect = 0;
							boolean read[] = new boolean[num_files];
							for (int i = 0; i < num_files; i++) {
								read[i] = false;
							}
							file_found = false;
							while (incorrect != num_files) {
								int index = rand.nextInt(num_files);
								if (fp.parse(index) == null && read[index] == false) {
									read[index] = true;
									incorrect++;	
								}
								else if (fp.parse(index) != null) {
									//save board
									crossword = fp.parse(index);
									crossword.render();
									file_found = true;
									break;
								}
							}
							
							if (file_found == false) {
								System.out.println("Could not find a file that was formatted correctly.");
								st.sendMessage("All files are not formatted correctly. Will look again when next client connects.");
							}
							else {
								System.out.println("File read successfully.");
							}
						}
						connected_players++;
						broadcast("Player " + connected_players + " has joined from " + s.getInetAddress(), st);
					}
					
					//if 1 player, game can start. if 2 or 3, server needs to wait for more players to join
				}
				if (file_found == false) {
					System.out.println("No files are formatted properly. Please add a formatted file. Game Server will terminate");
					broadcast("No files are formatted properly. Please add a formatted file. Game Server will terminate", null);
					System.exit(0);
				}
				
				System.out.println("Game can now begin.");
				//System.out.println(crossword.print()); 
				//create int array to hold point totals
				points = new int[num_players];
				for (int i = 0; i < num_players; i++) {
					points[i] = 0;
				}
				
				broadcast("The game is beginning.", null);
				started = true; // why is this not letting serverthread continue?

				int current_player = 0; //index of current player; start with player 1
				while (!finished) {
					//which player is currently playing?
					//this is where we will set the locks and such
					//set incorrect to false
					boolean incorrect = false;
					
					while (!incorrect) {
						System.out.println("Sending game board.");
						broadcast(crossword.print(), null); //broadcast the board and questions
						broadcast(crossword.printQuestions(), null);

						//broadcast other message to other players
						broadcast("Player " + (current_player+1) + "�s turn.", serverThreads.get(current_player));
						System.out.println("Player " + (current_player+1) + "�s turn.");
						//prompt current player
						question = 1;
						
						while (question != 4) {System.out.print("");}
						incorrect = true;
						question = 1;
						wait2 = false;
					}
					
					//increment player's turn
					if (current_player == num_players-1) {
						current_player = 0;
					}
					else {
						current_player++;
					}
				}
				 //game has finished
				
				//print out scores
				System.out.println("Game has concluded.");
				System.out.println("Sending out scores.");
				broadcast("Final Score:", null);
				int winner = 0;
				int max = 0;
				for (int i = 0; i < GameServer.num_players; i++) {
					broadcast("Player " + (i+1) + ": " + points[i] + " correct answers.", null);
					if (points[i] > max) {
						winner = i;
						max = points[i];
					}
				}
				
				//find player that won
				broadcast("Player " + (winner+1) + " is the winner.", null);
				//let ServerThread terminate
				wait = false;
				
			}
		}
		catch (IOException ioe) {
			System.out.println("ioe: " + ioe.getMessage());
		}
		finally {
			try {
				if (ss != null) ss.close();
			}
			catch (IOException ioe) {
				System.out.println("ioe closing ss: " + ioe.getMessage());
			}
		}
	}
	
//	public void ServerToClient (String message, ServerThread currentST) {
//		if (message != null) {
//			currentST.pw.println(message);
//			currentST.pw.flush();
//		}
//	}
	
	public void queryNumPlayers (ServerThread currentST) {
		//ServerToClient("How many players will there be?", currentST);
		//needs to wait for response
		while (num_players == 0) {}
		
	}
	
	public void broadcast(String message, ServerThread currentST) {
		if(message != null) {
			for (ServerThread st : serverThreads) { //iterates all over the serverThreads vector, with st being the current ServerThread
				if (st != currentST) { //if not the one sending the message, we forward this message
					st.sendMessage(message);
				}
			}
		}
	}
	
	//taken from lab
	public void pass(int rank) {
		//acquire rank's lock
		locks.get(rank).lock();
		//signal 
		conditions.get(rank).signal();
		locks.get(rank).unlock();
	}

	public static void main(String[] args) {
		GameServer gs = new GameServer(3456);

	}

}
