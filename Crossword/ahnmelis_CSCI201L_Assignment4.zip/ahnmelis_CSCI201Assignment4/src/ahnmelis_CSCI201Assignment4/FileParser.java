package ahnmelis_CSCI201Assignment4;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;
import java.util.Vector;

public class FileParser {
	//store vector of strings that are the file names
	private String folder;
	Vector<String> files;
	public FileParser(String folder) {
		this.folder = folder;
		files = new Vector<String>();
		//read in all files
		File dir = new File(folder);
		File[] directoryListing = dir.listFiles();
	    for (File child : directoryListing) {
	      files.add(child.getName());
	    }
	}
	
	public Board parse(int index) {
		//create new arraylist of words
    	ArrayList<Word> words = new ArrayList<Word>();
    	
    	//need some counters for how large the board should be
    	int rows = 0;
    	int columns = 0;
    	
		try {
			 //opens file
			FileReader in = new FileReader(folder + "/" + files.get(index));
		    BufferedReader br = new BufferedReader(in);
			//URL url = getClass().getResource("C:\\Users\\itsah\\eclipse-workspace\\ahnmelis_CSCI201Assignment4\\gamedata\\test.txt");
	    	//URL url = getClass().getResource("/../../gamedata/test.txt");
			//URL url = ClassLoader.getSystemResource("/../../gamedata/" + file);
	    	//System.out.println(url);
	    	//BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
	    	//reads through file
	  
	    	//set the orientation
	    	boolean ori = true; //default across
	    	boolean across_flag = false;
	    	boolean down_flag = false;
	    	
	    	
	    	//start parsing through file
	    	String line = br.readLine();
	    	while (line != null) {
	    		if (line.toUpperCase().equals("ACROSS")) {
	    			if (across_flag == true) { //if across already was listed
	    				return null;
	    			}
	    			//set orientation equal to true
	    			ori = true;
	    			across_flag = true;
	    			
	    		}
	    		else if (line.toUpperCase().equals("DOWN")) {
	    			if (down_flag == true) { //if down already was listed
	    				return null;
	    			}
	    			//set orientation equal to false
	    			ori = false;
	    			down_flag = true;
	    			
	    		}
	    		
	    		else if (across_flag == false && down_flag == false) { //first line was neither of the options
	    			return null;
	    		}
	    		else { //should be regular word
	    			//string tokenizer
	    			StringTokenizer st = new StringTokenizer(line, "|");
	    			int number = Integer.parseInt(st.nextToken());
	    			String term = st.nextToken();
	    			//need to gather the length of this term
	    			if (ori == true) {
	    				columns += term.length()+1;
	    			}
	    			else {
	    				rows += term.length();
	    			}
	    			//need to see if it shares a number with another term
	    			//iterate over all of the words
	    			for (int i = 0; i < words.size(); i++) {
	    				if (words.get(i).getNumber() == number) {
	    					if (words.get(i).getLetters().get(0).getChar() != term.charAt(0)) { //if the first letter of that word is not equal to the first letter of this word, return null
	    						return null;
	    					}
	    				}
	    			}
	    			String answer = st.nextToken();
	    			//create a word out of them and put it into the arraylist
	    			words.add(new Word(number, term, ori, answer));
	    			
	    		}
	    		
	    		line = br.readLine();
	    	}
	    	
		} catch (FileNotFoundException fnfe) {
			System.out.println("fnfe: " + fnfe.getMessage());
		} catch (IOException ioe) {
			System.out.println("ioe in FileParser: " + ioe.getMessage());
		} catch (NumberFormatException nfe) {
			System.out.println("nfe in FileParser: " + nfe.getMessage());
			return null;
		} catch (NoSuchElementException nsee) {
			return null;
		}
		
		//create a new board and return it
    	return new Board(words, rows, columns);
	}

}
