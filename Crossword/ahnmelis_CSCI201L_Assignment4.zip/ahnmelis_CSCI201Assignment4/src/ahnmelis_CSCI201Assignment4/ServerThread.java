package ahnmelis_CSCI201Assignment4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

//each ServerThread is only concerned with one client
public class ServerThread extends Thread {
	private BufferedReader br;
	private PrintWriter pw;
	private GameServer gs;
	private boolean direction;
	private int number;
	private String response;
	private Lock l;
	private Condition c;
	private int rank;
	boolean first;
	
	public ServerThread(Socket s, GameServer gs, Lock l, Condition c, int rank) {
		this.gs = gs;
		this.l = l;
		this.c = c;
		this.rank = rank;
		
		if (rank == 0) {
			first = true;
		}
		else {
			first = false;
		}
		
		try {
			
			br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			pw = new PrintWriter(s.getOutputStream());
			//before start
			if (gs.first_player == true) { // expecting an int
				pw.println("How many players will there be?");
				pw.flush();
				gs.num_players = br.read() - 48; //blocks?
				if (gs.num_players > 1) {
					pw.println("Waiting for player 2");
					pw.flush();
				}
				if (gs.num_players > 2) {
					pw.println("Waiting for player 3");
					pw.flush();
				}
				
			}
			else {
				pw.println("There is a game waiting for you");
				pw.flush();
				if (gs.connected_players >= 1) {
					pw.println("Player 1 has already joined");
					pw.flush();
				}
				if (gs.connected_players == 2){
					pw.println("Player 2 has already joined");
					pw.flush();
				}
				if (gs.num_players > 2) {
					pw.println("Waiting for player 3");
					pw.flush();
				}
				
			}
			this.start(); //only starts the thread if the br and pw were able to get the streams
		} catch (IOException ioe) {
			System.out.println("ioe in ServerThread: " + ioe.getMessage());
		}
	}
	
	public void sendMessage(String message) {
		pw.println(message);
		pw.flush();
	}
	public void run() {
		try {
			while (!GameServer.started) {System.out.print("");}
			while(GameServer.started) {
				l.lock(); //need to acquire lock so we can ensure that it is our turn
				if (!first && !GameServer.one_player) { //if very first turn, bypass this; need to add flag so only one player can play
					System.out.println("What about here? " + (rank+1));
					c.await(); //wait for signal
					
					if (GameServer.wait == true) {
						break;
					}
				}
				else {
					//first = false; //first turn should now be set to false for everyone
				}
				//entering the player's turn
				
				//serverThread will handle the answers from here

				while (GameServer.question == 1) {
					sendMessage("Would you like to answer a question across (a) or down (d)?");
					//wait for response
					String temp = br.readLine(); //this will break us out of our loop when the stream gets closed
					if (first) {
						temp = br.readLine();
						first = false;
					}
					if(temp.contentEquals("a") || temp.contentEquals("d")) {
						if (temp.contentEquals("a")) {
							direction = true;
						}
						else {
							direction = false;
						}
						//now prompt for number
						GameServer.question = 2;
						while (GameServer.question == 2) {
							sendMessage("Which number?");
							int temp2 = -1;
							try {
								temp2 = Integer.parseInt(br.readLine());
							} catch (NumberFormatException nfe) {
								
							}
							if (temp2 != -1) {		
								//need to first check if that number exists, and then if it does, check the orientation
								for (int i = 0; i < gs.crossword.getWords().size(); i++) {
									if (temp2 == gs.crossword.getWords().get(i).getNumber() && gs.crossword.getWords().get(i).getOri() == direction) {
										//prompt user for answer
										GameServer.question = 3;
										number = temp2;
										if (direction == true) {
											sendMessage("What is your guess for " + number + " across?");
										}
										else {
											sendMessage("What is your guess for " + number + " down?");
										}
										String temp3 = br.readLine();
										temp3 = temp3.toLowerCase();
										//check to see if this response matches the word
										if (gs.crossword.getWords().get(i).getStringForm().contentEquals(temp3)) {
											//CORRECT!
											sendMessage("That is correct!");
											response = temp3;
											GameServer.question = 1;
											//update score
											gs.points[rank]++;
											//print crossword with changes
											if (direction) {
												gs.broadcast("Player " + (rank+1) + " guessed \"" + temp3 + "\" for " + temp2 + " " + "across", this);
												System.out.println("Player " + (rank+1) + " guessed \"" + temp3 + "\" for " + temp2 + " " + "across");
											}
											else {
												gs.broadcast("Player " + (rank+1) + " guessed \"" + temp3 + "\" for " + temp2 + " " + "down", this);
												System.out.println("Player " + (rank+1) + " guessed \"" + temp3 + "\" for " + temp2 + " " + "down");
											}
											gs.broadcast("That is correct.", this);
											System.out.println("That is correct.");
											System.out.println("Sending game board.");
											//call function to update crossword
											gs.crossword.update(temp3);
											gs.broadcast(gs.crossword.print(), null);
											gs.broadcast(gs.crossword.printQuestions(), null);
											gs.broadcast("Still Player " + (rank+1) + "'s turn.", this);
											//could this have been the last word?
											if (gs.crossword.getWords().size() == 0) {
												//set up to end game
												GameServer.finished = true;
												GameServer.question = 4;	
												GameServer.started = false;
												//unlock all other players
												gs.wait = true;
												for (int j = 0; j < GameServer.num_players; j++) {
													if (j != rank) {
														gs.pass(j);
													}
												}
												
												
											}
											
										}
										else {
											sendMessage("That is incorrect!");
											if (direction) {
												gs.broadcast("Player " + (rank+1) + " guessed \"" + temp3 + "\" for " + temp2 + " " + "across", this);
												System.out.println("Player " + (rank+1) + " guessed \"" + temp3 + "\" for " + temp2 + " " + "across");
											}
											else {
												gs.broadcast("Player " + (rank+1) + " guessed \"" + temp3 + "\" for " + temp2 + " " + "down", this);
												System.out.println("Player " + (rank+1) + " guessed \"" + temp3 + "\" for " + temp2 + " " + "down");
											}
											
											gs.broadcast("That is incorrect.", this);
											System.out.println("That is incorrect.");
											GameServer.question = 4; //purposefully set it to four so that it will pass
										}
										//no matter what, we want to get out of this loop
										break;
									}
								}
							}
							
							if (GameServer.question == 2) {
								sendMessage("That is not a valid option.");
							}
							
						}
						
					}
					else {
						sendMessage("That is not a valid option.");
					} //should go back up to while loop
				}
				if (GameServer.wait == true) {
					break;
				}
				//at the end, let's pass the turn to next player
				while (GameServer.wait2) {System.out.print("");}
				if (rank == GameServer.num_players-1) {
					GameServer.question = 1;
					gs.pass(0);
					GameServer.wait2 = true;
				}
				else {
					System.out.println("Do we get in here? " + (rank+1));
					GameServer.question = 1;
					gs.pass(rank+1);
					GameServer.wait2 = true;
				}
				l.unlock();

			}
			
			//WAIT
			while(GameServer.wait) {System.out.print("");}

			//now can terminate
			sendMessage("Thanks for playing!"); //use this to terminate client
			
		} catch(IOException ioe) {
			System.out.println("ioe reading from br: " + ioe.getMessage());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

