package ahnmelis_CSCI201Assignment4;

public class Letter {
	private char c; //letter it represents
	private boolean shared; 
	
	public Letter(char c) {
		this.c = c;
		shared = false;
	}
	
	public char getChar() {
		return c;
	}

	
	public void setShared(boolean s) {
		shared = s;
	}
	
	public boolean getShared() {
		return shared;
	}


}
