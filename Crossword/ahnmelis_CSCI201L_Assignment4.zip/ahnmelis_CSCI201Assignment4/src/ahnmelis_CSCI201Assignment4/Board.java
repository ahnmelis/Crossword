package ahnmelis_CSCI201Assignment4;

import java.util.ArrayList;

public class Board {
	private ArrayList<Word> words;
	private int usedWords;
	private char[][] board;
	public Board(ArrayList<Word> words, int rows, int columns) {
		this.words = words;
		usedWords = 0;
		//create board beforehand
		board = new char[rows][columns];
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				board[i][j] = ' ';
			}
		}
	}
	public ArrayList<Word> getWords() {
		return words;
	}
	
	public boolean render() {
		//base case: there are no words left
		if (usedWords == words.size()) {
			//trim the board
			trim();
			//call blank function to reset
			blank();
			return true;
		}
		
		//loop through all the remaining words
		for (int i = 0; i < words.size(); i++) {
			//check to see if it has been used yet
			if (!words.get(i).getUsed()) {
				
				int r = -1;
				int c = -1;
				//if this word has the same index as another word on the board, it needs to start at that same spot
				boolean index_flag = false;
				for (int j = 0; j < words.size(); j++) {
					if (words.get(j).getUsed() && words.get(j).getNumber() == words.get(i).getNumber()) {
						r = words.get(j).getRow();
						c = words.get(j).getColumn();
						index_flag = true;
					}
				}
				
				if (index_flag) { //only check the one position
					int j = r;
					int k = c;
					if (words.get(i).getOri() == true && k+words.get(i).getLength() <= board[0].length) { //across
						
						//can the word be placed here?
						boolean flag = false;
						
						for (int l = 0; l < words.get(i).getLength(); l++) {
							if (board[j][k+l] != ' ' && board[j][k+l] != words.get(i).getLetters().get(l).getChar()) {
								flag = true; //word cannot be placed here
							}
							
							//search up and down of letter
							else if (j+1 < board.length && board[j+1][k+l] != ' '  && !Character.isDigit(board[j+1][k+l]) && board[j][k+l] != words.get(i).getLetters().get(l).getChar()) {
								flag = true;
							}
							
							else if (j-1 >= 0 && board[j-1][k+l] != ' ' && !Character.isDigit(board[j-1][k+l]) && board[j][k+l] != words.get(i).getLetters().get(l).getChar()) {
								flag = true;
							}
							//search right of last letter
							else if (l == words.get(i).getLength()-1 && k+l+1 < board[0].length && board[j][k+l+1] != ' ' && !Character.isDigit(board[j][k+l+1]) && board[j][k+l] != words.get(i).getLetters().get(l).getChar()) {
								flag = true;
							}
							//search left of first letter
							else if (l == 0 && k+l-1 >= 0 && board[j][k+l-1] != ' '  && !Character.isDigit(board[j][k+l-1]) && board[j][k+l] != words.get(i).getLetters().get(l).getChar()) {
								flag = true;
							}
							
						}
						
						if (flag == false ) {
							//we can place the word on the board
							//put number to the left first
							board[j][k-1] = (char)(words.get(i).getNumber() + '0');
							for (int l = 0; l < words.get(i).getLength(); l++) {
								if (board[j][k+l] == words.get(i).getLetters().get(l).getChar()) {
									words.get(i).getLetters().get(l).setShared(true);
									
								}
								board[j][k+l] = words.get(i).getLetters().get(l).getChar();
							}
							
							words.get(i).setUsed(true);
						}
					}
					
					else if (words.get(i).getOri() == false && j+words.get(i).getLength() <= board.length){ //down
						//can the word be placed here?
						boolean flag = false;
						
						for (int l = 0; l < words.get(i).getLength(); l++) {
							if (board[j+l][k] != ' ' && board[j+l][k] != words.get(i).getLetters().get(l).getChar()) {
								flag = true; //word cannot be placed here
							}
							
							//search left and right of letter
							else if (k+1 < board[0].length && board[j+l][k+1] != ' ' && board[j+l][k] != words.get(i).getLetters().get(l).getChar()) {
								flag = true;
							}
							
							else if (k-1 >= 0 && board[j+l][k-1] != ' ' && !Character.isDigit(board[j+l][k-1]) && board[j+l][k] != words.get(i).getLetters().get(l).getChar()) {
								flag = true;
							}
							
							//search down of last letter
							else if ((l == words.get(i).getLength()-1) && j+l+1 < board.length && board[j+l+1][k] != ' '  && !Character.isDigit(board[j+l+1][k]) && board[j+l][k] != words.get(i).getLetters().get(l).getChar()) {
								flag = true;
							}
							
							else if (l == 0 && j-1 >= 0 && board[j+l-1][k] != ' ' && !Character.isDigit(board[j+l-1][k]) && board[j+l][k] != words.get(i).getLetters().get(l).getChar()) {
								flag = true;
							}
							
						}
						
						if (flag == false) {
							//we can place the word on the board
							//put number to the left first
							board[j][k-1] = (char)(words.get(i).getNumber() + '0');
							for (int l = 0; l < words.get(i).getLength(); l++) {
								if (board[j+l][k] == words.get(i).getLetters().get(l).getChar()) {
									words.get(i).getLetters().get(l).setShared(true);
								}
								board[j+l][k] = words.get(i).getLetters().get(l).getChar();
							}
							
							words.get(i).setUsed(true);
						}
						
					}
					
					//was word successfully placed?
					
					if (words.get(i).getUsed() == true) {
						usedWords++;
						words.get(i).setRow(j);
						words.get(i).setColumn(k);
						
						if (render() == false) { //need to remove word
							if (words.get(i).getOri() == true) {
								for (int l = 0; l < words.get(i).getLength(); l++) {
									if (words.get(i).getLetters().get(l).getShared() != true) {
										board[j][k+l] = ' ';
									}
									//otherwise; leave character there because it was an intersect, but undo shared
									else {
										words.get(i).getLetters().get(l).setShared(false);
									}
								}
							}
							
							else {
								for (int l = 0; l < words.get(i).getLength(); l++) {
									if (words.get(i).getLetters().get(l).getShared() != true) {
										board[j+l][k] = ' ';
									}
									//otherwise; leave character there because it was an intersect, but undo shared
									else {
										words.get(i).getLetters().get(l).setShared(false);
									}
								}
							}
							
							usedWords--;
							words.get(i).setUsed(false);
							words.get(i).setRow(-1);
							words.get(i).setColumn(-1);
							
							
							
						}
						//otherwise, return true because we've found a board!
						else {
							return true;
						}
					}
					else {
						return false; //need to return false here because this was the only position the word could be placed
					}
				}
				//else, go through every spot on the board; check orientation first
				for (int j = 1; j < board.length; j++) {
					for (int k = 1; k < board[j].length; k++) {
						
						if (words.get(i).getOri() == true && k+words.get(i).getLength() <= board[0].length) { //across
					
							//can the word be placed here?
							boolean flag = false;
							//need new flag to make sure that word was shared at least once
							boolean shared_flag = false;
							if (usedWords == 0) { //if first word on board
								shared_flag = true;
							}
							for (int l = 0; l < words.get(i).getLength(); l++) {
								if (board[j][k+l] != ' ' && board[j][k+l] != words.get(i).getLetters().get(l).getChar()) {
									flag = true; //word cannot be placed here
								}
								
								//search up and down of letter
								else if (j+1 < board.length && board[j+1][k+l] != ' '  && !Character.isDigit(board[j+1][k+l]) && board[j][k+l] != words.get(i).getLetters().get(l).getChar()) {
									flag = true;
								}
								
								else if (j-1 >= 0 && board[j-1][k+l] != ' ' && !Character.isDigit(board[j-1][k+l]) && board[j][k+l] != words.get(i).getLetters().get(l).getChar()) {
									flag = true;
								}
								//search right of last letter
								else if (l == words.get(i).getLength()-1 && k+l+1 < board[0].length && board[j][k+l+1] != ' '  && !Character.isDigit(board[j][k+l+1]) && board[j][k+l] != words.get(i).getLetters().get(l).getChar()) {
									flag = true;
								}
								//search left of first letter
								else if (l == 0 && k+l-1 >= 0 && board[j][k+l-1] != ' '  && !Character.isDigit(board[j][k+l-1]) && board[j][k+l] != words.get(i).getLetters().get(l).getChar()) {
									flag = true;
								}
								
								else if (board[j][k+l] == words.get(i).getLetters().get(l).getChar() && l != 0) { //also put a condition for not being the first letter of the word
									shared_flag = true;
								}
								
							}
							
							if (flag == false && shared_flag == true) {
								//we can place the word on the board
								//put number to the left first
								board[j][k-1] = (char)(words.get(i).getNumber() + '0');
								for (int l = 0; l < words.get(i).getLength(); l++) {
									if (board[j][k+l] == words.get(i).getLetters().get(l).getChar()) {
										words.get(i).getLetters().get(l).setShared(true);
										
									}
									board[j][k+l] = words.get(i).getLetters().get(l).getChar();
								}
								
								words.get(i).setUsed(true);
							}
						}
						
						else if (words.get(i).getOri() == false && j+words.get(i).getLength() <= board.length){ //down
							//can the word be placed here?
							boolean flag = false;
							//need new flag to make sure that word was shared at least once
							boolean shared_flag = false;
							if (usedWords == 0) { //if first word on board
								shared_flag = true;
							}
							for (int l = 0; l < words.get(i).getLength(); l++) {
								if (board[j+l][k] != ' ' && board[j+l][k] != words.get(i).getLetters().get(l).getChar()) {
									flag = true; //word cannot be placed here
								}
								
								//search left and right of letter
								else if (k+1 < board[0].length && board[j+l][k+1] != ' ' && !Character.isDigit(board[j+l][k+1]) && board[j+l][k] != words.get(i).getLetters().get(l).getChar()) {
									flag = true;
								}
								
								else if (k-1 >= 0 && board[j+l][k-1] != ' ' && !Character.isDigit(board[j+l][k-1]) && board[j+l][k] != words.get(i).getLetters().get(l).getChar()) {
									flag = true;
								}
								
								//search down of last letter
								else if ((l == words.get(i).getLength()-1) && j+l+1 < board.length && board[j+l+1][k] != ' '  && !Character.isDigit(board[j+l+1][k]) && board[j+l][k] != words.get(i).getLetters().get(l).getChar()) {
									flag = true;
								}
								
								else if (l == 0 && j-1 >= 0 && board[j+l-1][k] != ' ' && !Character.isDigit(board[j+1-1][k]) && board[j+l][k] != words.get(i).getLetters().get(l).getChar()) {
									flag = true;
								}
								
								else if (board[j+l][k] == words.get(i).getLetters().get(l).getChar() && l != 0) {
									shared_flag = true;
								}
							}
							
							if (flag == false && shared_flag == true) {
								//we can place the word on the board
								//put number to the left first
								board[j][k-1] = (char)(words.get(i).getNumber() + '0');
								for (int l = 0; l < words.get(i).getLength(); l++) {
									if (board[j+l][k] == words.get(i).getLetters().get(l).getChar()) {
										words.get(i).getLetters().get(l).setShared(true);
									}
									board[j+l][k] = words.get(i).getLetters().get(l).getChar();
								}
								
								words.get(i).setUsed(true);
							}
							
						}
						
						//was word successfully placed?
						
						if (words.get(i).getUsed() == true) {
							usedWords++;
							words.get(i).setRow(j);
							words.get(i).setColumn(k);
							
							if (render() == false) { //need to remove word
								if (words.get(i).getOri() == true) {
									//get rid of number
									board[j][k-1] = ' ';
									for (int l = 0; l < words.get(i).getLength(); l++) {
										if (words.get(i).getLetters().get(l).getShared() != true) {
											board[j][k+l] = ' ';
										}
										//otherwise; leave character there because it was an intersect, but undo shared
										else {
											words.get(i).getLetters().get(l).setShared(false);
										}
									}
								}
								
								else {
									//get rid of number
									board[j][k-1] = ' ';
									for (int l = 0; l < words.get(i).getLength(); l++) {
										if (words.get(i).getLetters().get(l).getShared() != true) {
											board[j+l][k] = ' ';
										}
										//otherwise; leave character there because it was an intersect, but undo shared
										else {
											words.get(i).getLetters().get(l).setShared(false);
										}
									}
								}
								
								usedWords--;
								words.get(i).setUsed(false);
								words.get(i).setRow(-1);
								words.get(i).setColumn(-1);
								
							}
							//otherwise, return true because we've found a board!
							else {
								return true;
							}
						}
						
						//otherwise, do nothing and move to next spot on board			
						
					}
				}
				
				
				//if this word cannot be put on any spot, move to next word in list
				
			}
		}
		//no words can be placed anywhere, so backtrack
		return false;
		
	}
	
	public void trim() {
		//loop through all the rows; stop and break out once you reach a row that doesn't have any characters
		int row_counter = 1;
		boolean flag = false;
		for (int i = 1; i < board.length; i++) {
			for(int j = 0; j < board[0].length; j++) {
				if (board[i][j] != ' ') {
					flag = true;
				}
			}
			
			//row without any letters
			if (flag == false) {
				break;
			}
			else {
				row_counter++;
				flag = false;
			}
		}
		
		//create new board
		char[][] result = new char[row_counter][board[0].length]; 
		//fill new board
		for (int i = 0; i < row_counter; i++) {
			for (int j = 0; j < result[0].length; j++) {
				result[i][j] = board[i][j];
			}
		}
		
		//set equal to board
		board = result;
		System.out.println(row_counter);
	}
	
	public String print() {
		String result = new String();
		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board[0].length; j++) {
				//System.out.print(board[i][j]);
				result += board[i][j];
			}
			//System.out.print("\n");
			result += "\n";
		}
		return result;
	}
	
	
	public String printQuestions() {
		String result = new String();
		result += "Across \n";
		for (int i = 0; i < words.size(); i++) {
			if (words.get(i).getOri()) {
				result += words.get(i).getNumber() + " " + words.get(i).getAnswer() + "\n";
			}
		}
		
		result += "Down \n";
		for (int i = 0; i < words.size(); i++) {
			if (!words.get(i).getOri()) {
				result += words.get(i).getNumber() + " " + words.get(i).getAnswer() + "\n";
			}
		}
		
		return result;
		
	}
	
	public void blank() {
		//iterate through all words and put _ for every letter
		for (int i = 0; i < words.size(); i++) {
			//across or down?
			if (words.get(i).getOri()) {
				//iterate through columns
				for (int j = words.get(i).getColumn(); j < words.get(i).getColumn()+words.get(i).getLength(); j++ ) {
					board[words.get(i).getRow()][j] = '_';
				}
				
			}
			
			else {
				//iterate through rows
				for (int j = words.get(i).getRow(); j < words.get(i).getRow()+words.get(i).getLength(); j++ ) {
					board[j][words.get(i).getColumn()] = '_';
				}
			}
		}
	}
	
	public void update(String answer) {
		//look for word
		for (int i = 0; i < words.size(); i++) {
			if (words.get(i).getStringForm().contentEquals(answer)) {
				//fill board with word
				//across or down?
				if (words.get(i).getOri()) {
					//iterate through columns
					for (int j = words.get(i).getColumn(); j < words.get(i).getColumn()+words.get(i).getLength(); j++ ) {
						board[words.get(i).getRow()][j] = words.get(i).getLetters().get(j - words.get(i).getColumn()).getChar();
					}
				}
				
				else {
					//iterate through rows
					for (int j = words.get(i).getRow(); j < words.get(i).getRow()+words.get(i).getLength(); j++ ) {
						board[j][words.get(i).getColumn()] = words.get(i).getLetters().get(j - words.get(i).getRow()).getChar();
					}
				}
				
				//remove word from words array so we don't guess it again
				words.remove(i);
			}
		}
	}
	
	
	public static void main(String[] args) {
		//ArrayList<Word> temp = new ArrayList<Word>();
		//temp.add(new Word(1, "trojans", true));
		//temp.add(new Word(2, "dodgers", true));
		//temp.add(new Word(3, "csci", true));
		//temp.add(new Word(1, "traveler", false));
		//temp.add(new Word(4, "gold", false));
		//temp.add(new Word(5, "marshall", false));
		
		//temp.add(new Word(1, "hi", false));
		//temp.add(new Word(1, "hello", true));
		//temp.add(new Word(2, "hola", false));
		//temp.add(new Word(3, "adios", true));
		
		//Board test = new Board(temp, 18, 20);
		FileParser fp = new FileParser("gamedata");
		
		Board test = fp.parse(2);
		boolean flag = test.render();
		
		if (flag == true) {
			System.out.println(test.print());
		}
		
	}

}
