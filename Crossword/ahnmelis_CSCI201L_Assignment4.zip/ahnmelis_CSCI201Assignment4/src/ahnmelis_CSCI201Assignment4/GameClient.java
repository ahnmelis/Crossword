package ahnmelis_CSCI201Assignment4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class GameClient extends Thread {
	private BufferedReader br;
	private PrintWriter pw;
	Scanner scan = new Scanner(System.in);

	public GameClient() {
		Socket s = null;
		String hostname;
		int port;
		try {
			// first try to connect to server
			System.out.println("Welcome to 201 Crossword!");
			System.out.println("Enter the server hostname: ");
			hostname = scan.nextLine(); // blocks
			System.out.println("Enter the server port: ");
			port = Integer.parseUnsignedInt(scan.nextLine()); // blocks

			System.out.println("Trying to connect to " + hostname + ":" + port);
			s = new Socket(hostname, port);
			System.out.println("Connected to " + hostname + ":" + port);

			// is this the first player? if so, client needs to specify how many players
			// there are
			br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			pw = new PrintWriter(s.getOutputStream());

			// wait to start thread
			// ask about number of players first
			String line = br.readLine();
			System.out.println(line);
			if (line.equals("How many players will there be?")) {
				int num_players = scan.nextInt(); // blocks
				// send the number of players to the server for next steps
				pw.print(num_players);
				pw.flush();
			}
			
			//before we allow the user to write anything...
			this.start();

			while (true) {
				line = scan.nextLine();
				pw.println(line);
				pw.flush();
			}

		} catch (IOException ioe) {
			System.out.println("ioe: " + ioe.getMessage());

		} finally {
			try {
				if (s != null)
					s.close();
			} catch (IOException ioe) {
				System.out.println("ioe closing socket: " + ioe.getMessage());
			}
		}
	}

	public void run() {
		
		  try { 
			 // reads in stuff from server 
			  while(true) {
				  String line = br.readLine();
					System.out.println(line);
					if (line.contentEquals("Thanks for playing!")) {
						System.exit(0);
					}
			  }
		  
		  } catch (IOException ioe) {
		  System.out.println("ioe reading from server: " + ioe.getMessage()); }
		 
	}

	public static void main(String[] args) {
		GameClient gc = new GameClient(); // this is where we connect to a certain server
	}
}
